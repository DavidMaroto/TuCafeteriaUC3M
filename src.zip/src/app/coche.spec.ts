import { Coche } from './coche';

describe('Coche', () => {
  it('should create an instance', () => {
    expect(new Coche()).toBeTruthy();
  });
});
