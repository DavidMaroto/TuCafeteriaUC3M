import { Component,Input } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Coche,EstadoCoche } from './coche';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})


export class AppComponent {
  title = 'Micropráctica ANGULAR - 02';
  
  public EstadoCoche:any = EstadoCoche;
  
  public coches:Array<Coche>=[	new Coche('mercedes','clase A',new Date(2011,7,21),new Date(2018,3,1),4641,'coche01.jpg',EstadoCoche.BUENO),
							new Coche('seat','leon',new Date(2013,7,1),new Date(2018,2,1),2345,'coche02.jpg',EstadoCoche.MALO),
							new Coche('audi','a3',new Date(2009,10,2),new Date(2018,2,1),6120,'coche03.jpg',EstadoCoche.BUENO),
							new Coche('ferrari','488',new Date(2012,4,21),new Date(2018,2,1),11210,'',EstadoCoche.BUENO)];
  
  public filtro:string='';
   
  public getFiltrados():Array<number>{
	  var filtrados:Array<number>=[];
	  var indice:number=0;
	  for(var coche of this.coches)
	  {
		  if (coche.marca.lastIndexOf(this.filtro, 0) === 0) filtrados.push(indice);
		  indice=indice+1;
	  }
	return filtrados;
  }
 
  public cmd_vender(id)
  {
	  this.coches.splice(id,1);
  }
  
  public cmd_rebajar(id)
  {
	  this.coches[id].rebajar(); 
  }
  

}
